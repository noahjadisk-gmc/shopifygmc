import type { AppProps } from 'next/app';
import '@shopify/polaris/build/esm/styles.css';
import { AppProvider, Frame } from '@shopify/polaris';

export default function MyApp({ Component, pageProps }: AppProps) {
  return (
    <AppProvider i18n={{}}>
      <Frame>
        <Component {...pageProps} />
      </Frame>
    </AppProvider>
  );
}
