import { Card, Page, Text, BlockStack } from '@shopify/polaris';
import { useEffect, useState } from 'react';

export default function Home() {
  const [score, setScore] = useState<number | null>(null);

  useEffect(() => {
    // Placeholder score fetch — in real app call server GraphQL
    setScore(72);
  }, []);

  return (
    <Page title="Compliance Dashboard">
      <BlockStack gap="400">
        <Card>
          <Text as="h2" variant="headingMd">Compliance score</Text>
          <Text as="p" variant="bodyLg">{score ?? 'Loading...'}/100</Text>
        </Card>
        <Card>
          <Text as="h2" variant="headingMd">Next actions</Text>
          <ul>
            <li>Publish Privacy Policy</li>
            <li>Add DSAR page to footer</li>
            <li>Verify Google Merchant via meta tag</li>
          </ul>
        </Card>
      </BlockStack>
    </Page>
  );
}
